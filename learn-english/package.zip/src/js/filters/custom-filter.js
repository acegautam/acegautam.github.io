angular.module('customFilter', []).filter('lessdata', function() {

   return function (items, field) {
   var filtered = [];
   for (var i = 0; i < items.length; i++) {
      var item = items[i];
	  
     if (item.UE_day <= field && item.UE_theme !== 'Introduction') {
        filtered.push(item);
        }
      }
      return filtered;      
    };
   }).filter('unique', function() {

        return function (arr, field) {
        var o = {}, i, l = arr.length, r = [];
        for(i=0; i<l;i+=1) {
          if(arr[i][field] in o)
          {

          }else{
            o[arr[i][field]] = arr[i];  
          } 
        }        
        for(i in o) {
            r.push(o[i]);
        }
        return r;
      }
   }).filter('specialChar', function () {
    
        return function(text) {
        if(text) {
            var ttt =  text.replace(/~/g, '<br>');
            ttt = ttt.replace(/\{\{/g,'<strong>');
            ttt = ttt.replace(/\}\}/g,'</strong>');
            ttt = ttt.replace(/\[\[/g,'<em>');
            ttt = ttt.replace(/\]\]/g,'</em>');

            var startUrl = ttt.indexOf('{#');
            if(startUrl > -1) {
              var endUrl   = ttt.indexOf('#}');
              var rawUrl = ttt.substr(startUrl,endUrl);
              var urlToShow = rawUrl.replace('{#','');
              urlToShow = urlToShow.replace('#}','');
              var rawUrlArray = urlToShow.split('##');
              ttt = ttt.replace(rawUrl,'<a href="'+rawUrlArray[0]+'" target="_blank" >'+rawUrlArray[1]+'</a>');
             
            }
            return ttt;
        }
          return '';
    }
}).filter('enquiz', function () {
        return function(texten) {
        if(texten) {
            var en =  texten.replace(/_____/g, '$??');
            var testCondition = en.indexOf('$??');
            return en;
        }
          return '';
    }
}).filter('truncate', function () {
          return function (text, length, end) {
            if (isNaN(length))
                length = 10;

            if (end === undefined)
                end = " ";

            if (text.length <= length || text.length - end.length <= length) {
                return text;
            }
            else {
                return String(text).substring(0, length-end.length) + end;
      }
    };
}).filter('intersection', function() {

        return function (arr1, arr2) {
        var result = arr1.filter(function(n) {
            return arr2.indexOf(n.UE_content_id) > -1;
        });
        return result;
      }
});
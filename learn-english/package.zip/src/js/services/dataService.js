angular.module('bc-dataService', []).factory('dataService', ['$http', function($http) {
    return {
      getData: function(level,lotId,token) {
      	
		   	if(lotId === null)
          return $http.get('http://10.21.2.35:8082/rest/private/articles/'+token+'/'+level );
        else
          return $http.get('http://10.21.2.35:8082/rest/private/articles/sync/'+token+'/'+level+'/'+lotId);
      },
      getToken: function(appId) {
      	
      	 return $http.get('http://10.21.2.35:8082/chkToken/'+appId);  
    }

    }
}]);
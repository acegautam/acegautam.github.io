(function() {
	'use strict';
 	angular
		.module('bc-congratulation', [])
	 	.controller('congratulationController',['$scope','$filter','$window', function($scope,$filter,$window) {		
		
		var activeLevel = localStorage.getItem('activeLevel');
		if(activeLevel=='E'){ $scope.userLevel = 'Easy';}else if(activeLevel=='M'){$scope.userLevel = 'Medium';}else{$scope.userLevel = 'Difficult';}
				
	}]);
})()
(function() {
	'use strict';
 	angular
		.module('bc-article', [])
	 	.controller('articleDetailsController',['$scope','$sce', '$http','$state','$log','$rootScope','$stateParams','$filter','$window', function($scope,$sce, $http,$state, $log,$rootScope,$stateParams,$filter,$window) {		
		
		var activeLevel = localStorage.getItem('activeLevel');
		var latestLotData = JSON.parse(localStorage.getItem(activeLevel+'Data')).articles;
		var userData = JSON.parse(localStorage.getItem(activeLevel+'UserData'));
		var atext;

        $scope.myData = {};
        $scope.questionMessage ={};
		$scope.submitted = false;
		$scope.displayPage = true;	
		$scope.showBrd = {};
		$scope.showPrev={};
		
		if(userData.currentDay === 0 && $stateParams.articleId === "1") {
			atext = $filter('filter')(latestLotData, {UE_day:$stateParams.articleId})[0];
			$scope.nextArticle = parseInt(atext.UE_content_id) + 1;

		} else if (userData.currentDay === 0 && $stateParams.articleId !== "1") {
			atext = $filter('filter')(latestLotData, {UE_content_id:$stateParams.articleId})[0];

			if(atext.UE_theme !== "Introduction") {
				$scope.displayPage = false;
				$state.go('list');
			} else {
				$scope.nextArticle = parseInt(atext.UE_content_id) + 1;
			}

		} else {
		
			var readUserArticles = JSON.parse(localStorage.getItem(activeLevel+'readUserArticles'));
			if(readUserArticles == null)
					readUserArticles = [];

			atext = $filter('filter')(latestLotData, {UE_content_id:$stateParams.articleId})[0];

			if(atext.UE_categories === "Quiz Time") {
				$scope.nextArticle = parseInt(atext.UE_content_id) + 1;
			} else {
				readUserArticles.push(atext.UE_content_id);
				localStorage.setItem(activeLevel+'readUserArticles',JSON.stringify(readUserArticles));
				$scope.nextArticle = 0;
			}
		}

		$scope.listPage = 'details({articleId:nextArticle})';
		$scope.todaysTheme = atext.UE_theme;

		if(atext.UE_theme === 'Introduction') {
			$scope.categoryShow = 1;
			$scope.articleClassChange = 0;
			$rootScope.back = 'null';
			localStorage.setItem(activeLevel+'introArticles',atext.UE_content_id);
		} else {
			$scope.categoryShow = 0;
			$scope.articleClassChange = 1;
		}

		if(atext.UE_theme === 'Introduction' && atext.UE_categories !== 'Quiz Time') {
			$scope.showPrev.switch = 13;
		}

		if(atext.UE_categories === 'Quiz Time') {
			
			if(atext.UE_Content_type =='Q_F') {
				var	question				= $filter('specialChar')(atext.UE_content_text_en);			
				var fillInTheBlank	 		= $filter('enquiz')(question);
				var fillInTheBlankArray 	= fillInTheBlank.split('$??');
				var value1	= fillInTheBlankArray[0];
				var value2	= fillInTheBlankArray[1];
			}

			$scope.quizData = $filter('filter')(latestLotData, {UE_theme:atext.UE_theme, UE_categories: 'Quiz Time'});
			$scope.quizLength = $scope.quizData.length;
			var quizNumber = 0;		

			for (var j = 0; j < $scope.quizLength; j++) {
			   if(  $scope.quizData[j].UE_content_id !== atext.UE_content_id) {
					quizNumber++;
				} else {
					$scope.quizCount = quizNumber + 1 ;
					break;
				}
			}		
		
			/* display options*/
			$scope.questionMessage.switch = 3;
			var qcontentType 		= atext.UE_Content_type;// Q_O or Q_F
			var qoption 			= atext.UE_option_en;
			var qexplanation 		= atext.UE_explanation; 
			var optionArray 		= qoption.split('^');
			$scope.questionShow 	= 1;
			$scope.inputShow        = 1;
			$scope.submitShow       = 1;
			var qoptiondisplay		= optionArray[0];
			var optionAnswer		= optionArray[1];

			if(qcontentType=='Q_O') {
				$scope.inputShow		= 0;
				$scope.submitShow   	= 0;
				$scope.qoptionChoicedisplay 	= qoptiondisplay.split('~');
				$scope.button_clicked = false;
				
				$scope.checkAnswer = function(option) {
					$scope.button_clicked  = true;
					$scope.optionDetails   = $filter('specialChar')(qexplanation);
					$scope.clickedOption   = option;
					$scope.currectOption   = optionAnswer;
					$scope.showBrd.switch  = 11;	
					$scope.showPrev.switch = 13;		
					$rootScope.ansSubmitted[atext.UE_content_id] = option;
				}	
			}

			if($scope.quizCount === $scope.quizLength && atext.UE_day == '364')	{
				$scope.listPage = 'congratulation';
			}else if($scope.quizCount === $scope.quizLength && atext.UE_day != '364') {
				$scope.listPage = 'list';
			} 
					
		} else {
			$scope.questionShow 	= 0;
			$scope.inputShow        = 1;
			$scope.submitShow       = 1;
			$scope.quizCount = 0;
		}
		
		$scope.nextQusBtn = true;
		
		$scope.goBack = function(){
			$window.history.back();
		}

		$scope.checkQus = function() {
			  
			 if ($scope.quizForm.$valid) {
			 	$scope.processAns($scope.answer);
			 	$rootScope.ansSubmitted[atext.UE_content_id] = $scope.answer;
		    } else {
		    	$scope.submitted = true;
		    }
		}

		$scope.finishTest = function(){ //console.log("finish test",$scope.quizLength,$scope.quizCount);
			if($scope.quizCount === $scope.quizLength && atext.UE_theme != 'Introduction') {
				var quizId = (atext.UE_content_id - ($scope.quizLength - 1));
				readUserArticles.push(quizId.toString());
				localStorage.setItem(activeLevel+'readUserArticles',JSON.stringify(readUserArticles));
				if(atext.UE_day === '364')
					$state.go('congratulation');
				else
					$state.go('list');
			}
		}

		$scope.processAns = function(answer) {

			$scope.quizAns			= "Correct Answer is "+ optionArray[1];
			$scope.explanation	 	= $filter('specialChar')(qexplanation); //e
			$scope.correctAns       = optionArray[1];
			var mainAns				= $scope.correctAns ;
			$scope.qclass 			= "ans-default";
			$scope.qfillclass 		= "ans-default";
			$scope.answer         	= answer.toUpperCase();
		    $scope.correctAns     	= mainAns.toUpperCase();
		    $scope.showBrd.switch   = 12;	
		    $scope.showPrev.switch   = 13;

			if(angular.equals( $scope.answer, $scope.correctAns)) {
				$scope.qclass = "ans-right"; 
				$scope.qfillclass = "qerrimgtrue";					
			} else {
			 	$scope.qclass = "ans-wrong";
			 	$scope.qfillclass = "qerrimgfalse";
			}
			
			$scope.truefalse = true;
			$scope.qusBtn 	  = false;
			$scope.nextQusBtn = true;
    		$scope.nextQusBtn = !$scope.nextQusBtn;
    		$scope.qusBtn 	  = !$scope.qusBtn;
		}

		if(atext.UE_content_id in $rootScope.ansSubmitted && qcontentType=='Q_O' ) {
			$scope.checkAnswer($rootScope.ansSubmitted[atext.UE_content_id]);
		} else if(atext.UE_content_id in $rootScope.ansSubmitted && qcontentType !='Q_O') {
			$scope.processAns($rootScope.ansSubmitted[atext.UE_content_id]);
		}

		$scope.articleImage = atext.UE_image_name;
		$scope.categoryName = atext.UE_categories;
		$scope.theme 		= atext.UE_theme;
		$scope.articleTitle = atext.UE_title_en;
		$scope.aintday 		= '';

		if(atext.UE_theme === 'Introduction') {
			$scope.aintday 		= 8;
			$scope.aday 		= '';

			if(atext.UE_categories == 'Quiz Time') {
				$scope.aday 		= 0;	
			}
		} else {
			$scope.aday 		= atext.UE_day;
		}	
		var atextShow 		= atext.UE_content_text_en;
		$scope.articleText 	=  $filter('specialChar')(atextShow);
	}]);
})()
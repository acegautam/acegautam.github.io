(function() {
	'use strict';
 	angular
		.module('bc-home-complexityLevel', [])
		.controller('homeController',['$scope','$http','$log','$rootScope','$filter','$state','$stateParams','dataService', function($scope,$http,$log,$rootScope,$filter,$state,$stateParams,dataService) {
				
			var bcAppId = 'BcLearnEnglishApp';
			var init = function () {

				var mobileConnections = navigator.onLine;
				$scope.interneterr = mobileConnections;

				$scope.appTokenSaved = localStorage.getItem('appTokenSaved');

				
				$rootScope.ansSubmitted = [];
	 			$scope.switchLevel = 0;
	 			var complexityLevel = localStorage.getItem('activeLevel');
	 			var userData = localStorage.getItem(complexityLevel+'UserData');

				if(complexityLevel === null)
	 				localStorage.setItem('firstTimeFlaf','true');
	 			if(complexityLevel === null || ($stateParams.changeLevel && $stateParams.changeLevel === '1')) {
	 				$scope.switchLevel = 1;
	 			} else {

	 				var lotData = JSON.parse(localStorage.getItem(complexityLevel+'Data'));
	 				
	 				if(lotData !== null)
		 				var lotId = lotData.lotId;
		 			else
		 				var lotId = null;

		 			console.log($scope.appTokenSaved);
		 			if($scope.appTokenSaved === null) {

				 			dataService.getToken(bcAppId).then(
							function(tokendata) {
							localStorage.setItem('appTokenSaved',tokendata.data.token);
			 				dataService.getData(complexityLevel,lotId,tokendata.data.token).then(
							function(data) {
								if(angular.equals({}, data.data.Response.data)) {
					            	console.log('empty');
					            } else {
					            	localStorage.setItem(complexityLevel+'Data', JSON.stringify(data.data.Response.data));	
					            }
					            var chkIntro = localStorage.getItem(complexityLevel+'introArticles');
					            if(chkIntro === null)
				 					$state.go('list');
				 				else
				 					$state.go('details',{articleId:chkIntro});
			 				 },
					         function(errorPayload) {
					         	$log.error('failure loading1 ', errorPayload);
					         	$state.go('serverErr');
					         });
			 			}, function(errorPayload) {
					         	$log.error('failure loading1 ', errorPayload);
					         	$state.go('serverErr');
					    });
				 } else {

			 		dataService.getData(complexityLevel,lotId,$scope.appTokenSaved).then(
						function(data) {
							if(angular.equals({}, data.data.Response.data)) {
				            	
				            } else {
				            	localStorage.setItem(complexityLevel+'Data', JSON.stringify(data.data.Response.data));	
				            }
			 				var chkIntro = localStorage.getItem(complexityLevel+'introArticles');
					            if(chkIntro === null)
				 					$state.go('list');
				 				else
				 					$state.go('details',{articleId:chkIntro});
		 				 },
				         function(errorPayload) {
				         	$log.error('failure loading1 ', errorPayload);
				         	$state.go('serverErr');
				         });
				 }

	 			}
	 		}

	 		$scope.showList = function(complexityLevel) {
	 			
				localStorage.setItem('activeLevel',complexityLevel);
				var currentDate    = new Date();
				localStorage.setItem(complexityLevel+'accessDate',currentDate);
	 			var lotData = JSON.parse(localStorage.getItem(complexityLevel+'Data'));

	 			if(lotData !== null)
	 				var lotId = lotData.lotId;
	 			else
	 				var lotId = null;

	 			if($scope.appTokenSaved === null) {
				dataService.getToken(bcAppId).then(
					function(tokendata) {
						localStorage.setItem('appTokenSaved',tokendata.data.token);
					dataService.getData(complexityLevel,lotId,tokendata.data.token).then(
					function(data) {
						if(angular.equals({}, data.data.Response.data)) {
			            	console.log('empty');
			            } else {
			            	localStorage.setItem(complexityLevel+'Data', JSON.stringify(data.data.Response.data));	
			            }
						            
					var userData = localStorage.getItem(complexityLevel+'UserData');

		 			if(userData === null) {
		 				localStorage.setItem(complexityLevel+'UserData',JSON.stringify({accessDate:currentDate,currentDay:0,firstAccessDate:currentDate}));
		 				$state.go('details',{articleId:1});
		 			} else {
		 			   var chkIntro = localStorage.getItem(activeLevel+'introArticles');
					            if(chkIntro === null)
				 					$state.go('list',{accessLevel:complexityLevel});
				 				else
				 					$state.go('details',{articleId:chkIntro});
		 			}
		          },
		         function(errorPayload) {
		         		$log.error('failure loading 2', errorPayload);
			         	$state.go('serverErr');
			     });
				}, function(errorPayload) {

		         		$log.error('failure loading 2', errorPayload);
			         	$state.go('serverErr');
			     });
			} else {

				dataService.getData(complexityLevel,lotId,$scope.appTokenSaved).then(
					function(data) {
						if(angular.equals({}, data.data.Response.data)) {
			            	console.log('empty');
			            } else {
			            	localStorage.setItem(complexityLevel+'Data', JSON.stringify(data.data.Response.data));	
			            }
						            
					var userData = localStorage.getItem(complexityLevel+'UserData');

		 			if(userData === null) {
		 				localStorage.setItem(complexityLevel+'UserData',JSON.stringify({accessDate:currentDate,currentDay:0,firstAccessDate:currentDate}));
		 				$state.go('details',{articleId:1});
		 			} else {
		 				var chkIntro = localStorage.getItem(complexityLevel+'introArticles');
					            if(chkIntro === null)
				 					$state.go('list',{accessLevel:complexityLevel});
				 				else
				 					$state.go('details',{articleId:chkIntro});
		 			    
		 			}
		          },
		         function(errorPayload) {
		         		$log.error('failure loading 2', errorPayload);
			         	$state.go('serverErr');
			     });
			}
		}
			init();
	}]);
})();
(function() {
	'use strict';
 	angular
		.module('bc-home', [])
	 	.controller('articleListController',['$scope','$http','$log','$rootScope','$filter','$stateParams', function($scope,$http,$log,$rootScope,$filter,$stateParams) {

			var nextPageOffset    = 1;
			var articleLimit      = 7;

			$scope.lotData        = null;
	 		$scope.perPagelotData = null;
			$scope.perPageLimit   = 5;
			$rootScope.ansSubmitted = [];
						
			$scope.loadMoreLot = function() {

				nextPageOffset = nextPageOffset + 1;
				var nextOffset = nextPageOffset * $scope.perPageLimit;
				$scope.perPagelotData =  $filter('limitTo')($scope.lotData, nextOffset);

				if($scope.lotData.length > $scope.perPagelotData.length)
					$scope.showMore = true;
				else
					$scope.showMore = false;
			}

			$scope.quizCountGet = localStorage.getItem('quizCountSet');
			$scope.quizTodayTheme = localStorage.getItem('quizTodayTheme');

			$scope.removeOpacity= function($event) {
				$scope.firstTimeFlaf = 'false';
				localStorage.setItem('firstTimeFlaf',$scope.firstTimeFlaf);
			}
			
			$scope.menuToggle = function(checked) {
				$scope.checked = !checked;
			}

			$scope.fetchNextArticle = function() {				
				$scope.cday++;				
				localStorage.setItem($scope.activeLevel+'UserData',JSON.stringify({accessDate:$scope.userData.accessDate,currentDay:($scope.cday),firstAccessDate:$scope.userData.firstAccessDate}));
				var lessLotData        = $filter('lessdata')($scope.latestLotData,$scope.cday);
				$scope.lotData         = $filter('unique')(lessLotData,'UE_day').reverse();
				$scope.perPagelotData  = $filter('limitTo')($scope.lotData, ($scope.perPagelotData.length +1));
				$scope.todaysTheme     = $scope.perPagelotData[0].UE_theme;
				
				if($scope.cday >= $scope.limitDisplay)
					$scope.nextArticle = false;
				else
					$scope.nextArticle = true;
			}
			
			var init = function() {				
				$scope.firstTimeFlaf = localStorage.getItem('firstTimeFlaf');
				$rootScope.back = 'list';
				var currentDate    = new Date();
				currentDate.setHours(0,0,0,0);
				

				if($stateParams.accessLevel) {
					$scope.activeLevel = $stateParams.accessLevel;
				} else {
					$scope.activeLevel = localStorage.getItem('activeLevel');	
				}
				var chkIntro = localStorage.getItem($scope.activeLevel+'introArticles');
				if(chkIntro !== null)
					localStorage.removeItem($scope.activeLevel+'introArticles');

				$scope.userData    = JSON.parse(localStorage.getItem($scope.activeLevel +'UserData'));
				var lastAccess = localStorage.getItem($scope.activeLevel+'accessDate');
				var lastAccessDate    = new Date(lastAccess);
				lastAccessDate.setHours(0,0,0,0);
				var dayPast = Math.ceil((currentDate - lastAccessDate) / (60 * 60 * 24 * 1000));
				var limitData = localStorage.getItem($scope.activeLevel+'limitData');

				if(limitData === null) {
					var dayShow = 1;
					$scope.limitDisplay = articleLimit;
					localStorage.setItem($scope.activeLevel+'limitData',$scope.limitDisplay);
				} else if(dayPast > 0){
					var dayShow = $scope.userData.currentDay + dayPast;
					$scope.limitDisplay = dayShow + (articleLimit - 1);
					localStorage.setItem($scope.activeLevel+'limitData',$scope.limitDisplay);
				} else {
					var dayShow = $scope.userData.currentDay;
					$scope.limitDisplay = limitData;
				}

				localStorage.setItem($scope.activeLevel+'accessDate',currentDate);
							
				if($scope.userData.currentDay >= $scope.limitDisplay)
					$scope.nextArticle = false;
				else
					$scope.nextArticle = true;

				$scope.readArticles   = JSON.parse(localStorage.getItem($scope.activeLevel+'readUserArticles'));
				$scope.cday 		  = dayShow;
				localStorage.setItem($scope.activeLevel+'UserData',JSON.stringify({accessDate:$scope.userData.accessDate,currentDay:$scope.cday,firstAccessDate:$scope.userData.firstAccessDate}));
				$scope.latestLotData  = JSON.parse(localStorage.getItem($scope.activeLevel+'Data')).articles;
				var lessLotData 	  = $filter('lessdata')($scope.latestLotData,dayShow);
				$scope.lotData  	  = $filter('unique')(lessLotData,'UE_day').reverse();
				$scope.perPagelotData = $filter('limitTo')($scope.lotData, $scope.perPageLimit);

				if($scope.lotData.length > $scope.perPagelotData.length)
					$scope.showMore = true;
				else
					$scope.showMore = false;

				$scope.todaysTheme  = $scope.perPagelotData[0].UE_theme;
			};
			init();
		}]);
})();
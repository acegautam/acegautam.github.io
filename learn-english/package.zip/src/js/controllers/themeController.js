(function() {
	'use strict';
 	angular
		.module('bc-theme', [])
	 	.controller('themeController',['$scope','$filter','$window','$rootScope', function($scope,$filter,$window,$rootScope) {		
		
		var activeLevel = localStorage.getItem('activeLevel');
		var latestLotData = JSON.parse(localStorage.getItem(activeLevel+'Data')).articles;
		var userData = JSON.parse(localStorage.getItem(activeLevel+'UserData'));

		$scope.activeTheme = '';
		$scope.goBack = function(){
			$window.history.back();
		}

		$scope.themeDetails = function(themeName) {

			if($scope.activeTheme !== themeName) {
				$scope.activeTheme = $scope.activeTheme;
				var detailsData = $filter('filter')($scope.lessLotData,{'UE_theme':themeName});
				$scope.themeDetailsData      = $filter('unique')(detailsData,'UE_categories').reverse();
				$scope.activeTheme = $scope.themeDetailsData[0].UE_theme;
			} else {
				$scope.activeTheme = '';
			}
		}
		
		$scope.lessLotData 	  = $filter('lessdata')(latestLotData,userData.currentDay);

		$rootScope.back = 'theme';
		$scope.themeData      = $filter('unique')($scope.lessLotData,'UE_theme').reverse();
		$scope.readArticles   = JSON.parse(localStorage.getItem(activeLevel+'readUserArticles'));

		if($scope.readArticles==null) {
			console.log("test in null");
			$scope.readArticles =[];
		}
				
	}]);
})()
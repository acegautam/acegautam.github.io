(function() {
	'use strict';
 	angular
		.module('bc-about', [])
	 	.controller('aboutController',['$scope','$filter','$window', function($scope,$filter,$window) {
		$scope.feedback = function() {	
			 var mailTo = "learnenglish.mobile@britishcouncil.org";
			 var mailSubject = "Feedback on LearnEnglish";
		     var mailbody = "My Feedback:";
		     window.location.href = "mailto:"+mailTo+"?subject="+mailSubject+"&body="+mailbody;
		}
		$scope.menuToggle = function(checked) {
			 $scope.checked = !checked;
		}		
	}]);
})()
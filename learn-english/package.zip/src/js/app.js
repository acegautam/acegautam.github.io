(function() {
	'use strict';
	window.onload=function() {
       window.setTimeout(function() {
           angular.bootstrap(document.body,['LearnEnglish']);
        },2000);
    }
	angular
		.module('LearnEnglish',['bc-home-complexityLevel','bc-home','bc-article','bc-dataService','bc-theme','bc-about','bc-congratulation','ui.router','customFilter','ngSanitize','ngRoute','ngTouch','swipe'])
		.config(['$locationProvider', '$httpProvider','$urlRouterProvider','$stateProvider','$compileProvider',function($locationProvider, $httpProvider,$urlRouterProvider,$stateProvider,$compileProvider) {
			$urlRouterProvider.otherwise('home/0');
			$stateProvider.state('home',{
				url : '/home/:changeLevel',
				templateUrl: 'src/includes/home.html',
				controller : 'homeController'
			}).state('about', {
		        url: '/about',
		     	templateUrl: 'src/includes/about.html',
	            controller: 'aboutController'
		    }).state('congratulation', {
		        url: '/congratulation',
		     	templateUrl: 'src/includes/congratulation.html',
	            controller: 'congratulationController'
		    })
			.state('list', {
		        url: '/list/:accessLevel',
		     	templateUrl: 'src/includes/list-start.html',
	            controller: 'articleListController'
		    }).state('theme', {
	            url: '/theme',
	            // loaded into ui-view of parent's template
	            templateUrl: 'src/includes/theme-index.html',
	            controller: 'themeController'
	        }).state('serverErr', {
	        	 url: '/err',
	            // loaded into ui-view of parent's template
	            templateUrl: 'src/includes/server-error.html'
	            
	        }).state('details', {
	            url: '/:articleId',
	            // loaded into ui-view of parent's template
	            templateUrl: 'src/includes/list-details.html',
	            controller: 'articleDetailsController'
	        })
	        
	        //$locationProvider.html5Mode(true);
			$httpProvider.defaults.useXDomain = true;
			delete $httpProvider.defaults.headers.common['X-Requested-With'];
			$compileProvider.imgSrcSanitizationWhitelist(/^\s*((https?|ftp|file|app):|data:image\/)/);
		}]);
})();
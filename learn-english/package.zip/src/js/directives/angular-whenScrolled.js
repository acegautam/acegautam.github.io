
angular.module('angular-whenScrolled', []).directive('whenScrolled', function ($window) {
 return {
      restrict: 'A',
      link: function (scope, elem, attrs) {
 
        var raw = elem[0];
 
        var funCheckBounds = function(evt) {
          //console.log('event fired: ' + evt.type);
          var rectObject = raw.getBoundingClientRect();
          if (rectObject.bottom === $window.innerHeight) {
            scope.$apply(attrs.whenScrolled);
          }
        };
        
        angular.element($window).bind('scroll load', funCheckBounds);
      }
    };
});
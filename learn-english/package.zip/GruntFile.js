module.exports = function(grunt) {
  grunt.initConfig({  
  /*
  compress: {
	  main: {
	    options: {
	      archive: function () {
	        // The global value git.tag is set by another task
	        return git.tag + '.zip'
	      }
	    },
	    files: [
	      {expand: true, src: ['src/*.js'], dest: 'dist/'}
	    ]
	  }
	}

  });
*/
    
  //grunt.loadNpmTasks('grunt-contrib-compress');

  //grunt.registerTask('default', ['compress']);
};